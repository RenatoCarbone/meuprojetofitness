// ============================================================
// AUTH.JS — Autenticação Google via Supabase
// ============================================================

// ─── Perfil pendente do quiz ───
function perfilQuizValido(perfil) {
  return !!(
    perfil &&
    typeof perfil === 'object' &&
    !Array.isArray(perfil) &&
    Object.keys(perfil).length > 0 &&
    Number(perfil.peso) > 0 &&
    Number(perfil.edad) > 0
  );
}

function normalizarPerfilQuiz(perfil) {
  if (!perfilQuizValido(perfil)) return null;

  const perfilNormalizado = { ...perfil };
  if (!Number(perfilNormalizado.pesoActual) && Number(perfilNormalizado.peso) > 0) {
    perfilNormalizado.pesoActual = Number(perfilNormalizado.peso);
  }
  return perfilNormalizado;
}

function parsePerfilQuiz(raw) {
  if (!raw || typeof raw !== 'string') return null;
  try {
    return normalizarPerfilQuiz(JSON.parse(raw));
  } catch (e) {
    return null;
  }
}

function recuperarPerfilQuiz() {
  const fontes = [
    localStorage.getItem('miplanfit_perfil'),
    sessionStorage.getItem('miplanfit_perfil'),
    sessionStorage.getItem('miplanfit_perfil_backup'),
    localStorage.getItem('miplanfit_perfil_backup')
  ];

  for (const fonte of fontes) {
    const perfil = parsePerfilQuiz(fonte);
    if (perfil) return perfil;
  }

  const cookieMatch = document.cookie.match(/(?:^|; )miplanfit_perfil_ck=([^;]+)/);
  if (cookieMatch) {
    try {
      const perfil = normalizarPerfilQuiz(JSON.parse(decodeURIComponent(cookieMatch[1])));
      if (perfil) return perfil;
    } catch (e) {}
  }

  // Compatibilidade temporária com links OAuth criados por versões antigas.
  const url = new URL(window.location.href);
  const legacyPdata = url.searchParams.get('pdata');
  if (legacyPdata) {
    try {
      const perfil = normalizarPerfilQuiz(JSON.parse(decodeURIComponent(escape(atob(legacyPdata.replace(/\s/g, '+'))))));
      if (perfil) return perfil;
    } catch (e) {}
  }

  return null;
}

function removerPdataLegadoDaUrl() {
  const url = new URL(window.location.href);
  if (!url.searchParams.has('pdata')) return;
  url.searchParams.delete('pdata');
  window.history.replaceState({}, document.title, url.pathname + (url.search ? url.search : '') + url.hash);
}

// ─── Login com Google ───
async function loginComGoogle() {
  const client = getSupabase();
  if (!client) return false;

  // O localStorage/sessionStorage do mesmo domínio permanece disponível após OAuth.
  // Não enviar dados de saúde do usuário na URL de redirecionamento.
  const refCode = localStorage.getItem('miplanfit_ref_by') || sessionStorage.getItem('miplanfit_ref_by') || new URLSearchParams(window.location.search).get('ref');
  let redirectTarget = SITE_URL + '/plano.html';

  if (refCode) {
    redirectTarget += `?ref=${encodeURIComponent(refCode.trim().toLowerCase())}`;
  }

  const { error } = await client.auth.signInWithOAuth({
    provider: 'google',
    options: { redirectTo: redirectTarget }
  });

  if (error) {
    console.error('Google login error:', error.message);
    return false;
  }
  return true;
}

// ─── Obter usuário atual ───
async function getUsuarioAtual() {
  const client = getSupabase();
  if (!client) return null;
  try {
    const { data: { session } } = await client.auth.getSession();
    return session?.user || null;
  } catch (e) {
    return null;
  }
}

// ─── Logout ───
async function logout() {
  const client = getSupabase();
  if (client) await client.auth.signOut();
  ['miplanfit_perfil','miplanfit_plan30','miplanfit_plan_id',
   'miplanfit_imc','miplanfit_tmb','miplanfit_tdee'].forEach(k => localStorage.removeItem(k));
  window.location.href = 'index.html';
}

// Helper: Generar código de referido único, limpio y consistente usando el primer nombre
function generarCodigoReferido(userId, nombre) {
  const firstName = (nombre || 'user').trim().split(/\s+/)[0];
  const nameClean = firstName.toLowerCase().replace(/[^a-z0-9]/g, '').substring(0, 8) || 'user';
  const shortId = (userId || '').replace(/[^a-z0-9]/gi, '').substring(0, 4);
  return `${nameClean}_${shortId || 'ref'}`;
}

// ─── Salvar plano na nuvem ───
async function salvarPlanoNaNuvem(userId, dados = {}) {
  const client = getSupabase();
  if (!client || !userId) return false;

  const perfil = normalizarPerfilQuiz(dados.perfil);
  if (!perfil) {
    console.error('Perfil inválido: o plano não foi salvo para evitar gravar perfil vazio.', dados.perfil);
    return false;
  }

  let email = dados.user_email || perfil.email || '';
  let nombre = dados.user_name || perfil.nombre || 'Usuario';

  try {
    const { data: { session } } = await client.auth.getSession();
    if (session?.user?.email) {
      email = session.user.email;
      const gName = session.user.user_metadata?.full_name || session.user.user_metadata?.name;
      if (gName && gName.trim() && gName.toLowerCase() !== 'usuario') {
        nombre = gName;
      }
    }
  } catch (e) {
    console.warn('Não foi possível obter a sessão ao salvar o plano.', e);
  }

  const myRefCode = dados.referral_code || generarCodigoReferido(userId, nombre);
  const urlRef = new URLSearchParams(window.location.search).get('ref');
  const referredByCode = dados.referred_by || localStorage.getItem('miplanfit_ref_by') || sessionStorage.getItem('miplanfit_ref_by') || urlRef || null;

  const payload = {
    user_id: userId,
    user_email: email,
    user_name: nombre,
    referral_code: myRefCode,
    perfil,
    updated_at: new Date().toISOString()
  };

  if (Array.isArray(dados.plan30)) payload.plan30 = dados.plan30;
  if (referredByCode && referredByCode !== myRefCode) payload.referred_by = referredByCode;

  const { error } = await client
    .from('planos')
    .upsert(payload, { onConflict: 'user_id' });

  if (error) {
    console.error('Erro ao salvar plano e perfil no Supabase:', error.message, error);
    return false;
  }

  console.log('Plano e perfil salvos com sucesso na nuvem:', myRefCode);

  if (referredByCode && referredByCode !== myRefCode && !sessionStorage.getItem(`miplanfit_ref_credited_${userId}`)) {
    sessionStorage.setItem(`miplanfit_ref_credited_${userId}`, 'true');
    await processarIndicacaoNaNuvem(referredByCode, userId);
  }

  return true;
}

// ─── Incrementar contador del patrocinador y dar Premium al llegar a 3 ───
async function processarIndicacaoNaNuvem(referrerCode, newUserId) {
  const client = getSupabase();
  if (!client || !referrerCode) return;

  try {
    const cleanCode = referrerCode.trim().toLowerCase();

    // 1. Buscar al usuario patrocinador por su código exacto de referido
    let { data: referrer, error: searchErr } = await client
      .from('planos')
      .select('*')
      .eq('referral_code', cleanCode)
      .maybeSingle();

    // Fallback: si no lo encuentra con coincidencia exacta, buscar por el prefijo del nombre (ej: renato_)
    if (!referrer) {
      const codePart = cleanCode.split('_')[0];
      if (codePart && codePart.length >= 3) {
        const { data: fallbackList } = await client
          .from('planos')
          .select('*')
          .ilike('referral_code', `${codePart}_%`);

        if (fallbackList && fallbackList.length > 0) {
          referrer = fallbackList[0];
        }
      }
    }

    if (searchErr || !referrer) {
      console.log('Patrocinador no encontrado para el código:', cleanCode);
      return;
    }

    // Evitar que el patrocinador sea la misma persona
    if (referrer.user_id === newUserId) return;

    let list = referrer.referrals_list || [];
    if (!Array.isArray(list)) list = [];

    // Si este nuevo usuario aún no ha sido contado para este patrocinador
    if (!list.includes(newUserId)) {
      list.push(newUserId);
    }

    const newCount = list.length;
    const shouldBePremium = referrer.is_premium || newCount >= 3;

    await client.from('planos').update({
      referrals_count: newCount,
      referrals_list : list,
      is_premium     : shouldBePremium,
      updated_at     : new Date().toISOString()
    }).eq('user_id', referrer.user_id);

    console.log(`🎉 ¡Indicación procesada! ${referrer.user_name} ahora tiene ${newCount} referidos. Premium: ${shouldBePremium}`);

    // Limpiar localStorage de invitación
    localStorage.removeItem('miplanfit_ref_by');
    sessionStorage.removeItem('miplanfit_ref_by');
  } catch(e) {
    console.error('Error al procesar indicación:', e);
  }
}

// ─── Carregar plano da nuvem ───
async function carregarPlanoNaNuvem(userId) {
  const client = getSupabase();
  if (!client) return null;

  const { data, error } = await client
    .from('planos').select('*').eq('user_id', userId).maybeSingle();

  if (error) {
    console.error('Erro ao carregar plano:', error.message);
    return null;
  }
  return data || null;
}

// ─── Salvar progresso na nuvem ───
async function salvarProgressoNaNuvem(userId, progresso) {
  const client = getSupabase();
  if (!client) return false;

  const { error } = await client.from('planos').update({
    dias_completados: progresso.diasCompletados || [],
    streak_actual   : progresso.streakActual    || 0,
    max_streak      : progresso.maxStreak       || 0,
    logros          : progresso.logros          || [],
    updated_at      : new Date().toISOString()
  }).eq('user_id', userId);

  if (error) {
    console.error('Erro ao salvar progresso:', error.message);
    return false;
  }
  return true;
}
